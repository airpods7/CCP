const searchInput = document.querySelector('.searchTerm');
const productsContainer = document.querySelector('.shop-container');
const products = document.querySelectorAll('.product');

searchInput.addEventListener('input', () => {
  const searchTerm = searchInput.value.toLowerCase();

  products.forEach(product => {
    const productName = product.querySelector('h4').textContent.toLowerCase();

    if (productName.includes(searchTerm)) {
      product.style.display = 'block';
    } else {
      product.style.display = 'none';
    }
  });
});


const selectElement = document.querySelector('.selection select');
const productContainer = document.querySelector('.shop-container');

selectElement.addEventListener('change', () => {
  const selectedOption = selectElement.value;
  const products = Array.from(productsContainer.querySelectorAll('.product'));

  products.forEach(product => {
    product.style.order = ''; // Reset order initially
  });

  products.sort((a, b) => {
    const getPrice = (product) => {
      const salePriceElement = product.querySelector('.sale-price');
      if (salePriceElement) {
        const priceText = salePriceElement.textContent.replace('Rs. ', '');
        return parseFloat(priceText.replace(',', '')); // Handle potential commas in price
      }
      return Infinity; // Handle products without sale price
    };

    const priceA = getPrice(a);
    const priceB = getPrice(b);

    if (selectedOption === 'Low to High') {
      return priceA - priceB;
    } else if (selectedOption === 'High to Low') {
      return priceB - priceA;
    }
    return 0; // Default to no sorting
  });

  // Assign order based on the sorted index
  products.forEach((product, index) => {
    product.style.order = index;
  });
});